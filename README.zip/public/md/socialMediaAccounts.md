# 社交網路
### 1. [X](https://x.com/HosinoEJ)
### 2. [YouTube](https://youtube.com/@HosinoEJ)
### 3. [GitHub](https://github.com/HosinoEJ)
### 4. [Discord](https://reurl.cc/8Dz8d7)
### 5. [Bilibili](https://space.bilibili.com/1140685131)
### 6. [mail](mailto:hosinoeiji@gmail.com)