# 自介



Ciallo！大家好，我是星野栄治，來自**中國大陸**，英文HosinoEJ來自日文ほしのえいじ（星野栄治的假名拼寫）原b站一個UP主,但是永久停更,現在在YouTube製作影片，~~其實還沒做的啦。~~

日期支持民國曆和日本曆

**語言**：ZH_CN | ZH_TW | Ja_JP

喜歡玩**麥塊**，願意的話可以一起玩的啦。也喜歡玩**Galgame**。

原先是建政頻道，現在不做。

現在正在學習日語，計畫令和七年10月份考N2，令和八年4月計畫去日本留學。現在偶爾會給github的開源項目製作日本語翻譯

謝絕加微信和QQ，但是可以加DISCORD。如果我們很熟悉的話可以加LINE或Whatsapp。

Bitcoin感謝投喂：**bc1psmmsscgms42g0s5xknvf85yy9evj7ftac3agk3v3zvfjun3n0hfsgqfnml**