# 現在正在進行的項目
## 特別項目：[星の日記](/port/20250708.zh-tw.TheJournalOf_STAR)
那個我心中的女孩
## 1. [MTF大調查](https://naniang.hsnej.fun/)
這是我（HosinoEJ）在民國114年（2025年）發起的一項公益性的社會調查。旨在為社會和學術上提供一個MTF群體現狀數據，以此讓人們認識到MTF群體的現狀。
## 2. [MTF數據分析](https://chiyu.it/posts/2025/report1)
感謝推友[@Chiyuyu520](https://x.com/Chiyuyu520)的數據提供，目前本人在數據分析中...